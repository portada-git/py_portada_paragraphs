# py_portada_paragraphs
Segmentación de bloques de única columna en párrafos
