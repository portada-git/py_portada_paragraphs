# py_yolo_paragraphs
Segmentación de imágenes de única columna en párrafos
